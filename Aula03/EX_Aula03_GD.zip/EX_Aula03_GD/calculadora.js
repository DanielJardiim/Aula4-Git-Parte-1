const validate = require('validate.js');
const CalculadoraConstraint = require('./validate');

const Calculadora = {
    logbasev1(num1, num2) {
        const validateNum1 = validate({ num1 },  CalculadoraConstraint.calculadoraConstraint);
        const validateNum2 = validate({ num2 },  CalculadoraConstraint.calculadoraConstraint);

        if((validateNum1 !== undefined) && (validateNum2 !== undefined) ){
            return 'Error';
        }
        var l = num1 ** num2;
        return l;
    },
    
    soma(num1, num2) {
        const validateNum1 = validate({ num1 },  CalculadoraConstraint.calculadoraConstraint);
        const validateNum2 = validate({ num2 },  CalculadoraConstraint.calculadoraConstraint);

        if((validateNum1 !== undefined) && (validateNum2 !== undefined) ){
            return 'Error';
        }
        var s = num1 + num2;
        return s;
    },

    subtracao(num1, num2) {
        const validateNum1 = validate({ num1 },  CalculadoraConstraint.calculadoraConstraint);
        const validateNum2 = validate({ num2 },  CalculadoraConstraint.calculadoraConstraint);

        if((validateNum1 !== undefined) && (validateNum2 !== undefined) ){
            return 'Error';
        }
        var s = num1 - num2;
        return s;
    },

    multiplicacao(num1, num2) {
        const validateNum1 = validate({ num1 },  CalculadoraConstraint.calculadoraConstraint);
        const validateNum2 = validate({ num2 },  CalculadoraConstraint.calculadoraConstraint);

        if((validateNum1 !== undefined) && (validateNum2 !== undefined) ){
            return 'Error';
        }
        var m = num1 * num2;
        return m;
    },

    divisao(num1, num2) {
        const validateNum1 = validate({ num1 },  CalculadoraConstraint.calculadoraConstraint);
        const validateNum2 = validate({ num2 },  CalculadoraConstraint.calculadoraConstraint);

        if((validateNum1 !== undefined) && (validateNum2 !== undefined) ){
            return 'Error';
        }
        var d = num1 / num2;
        return d;
    }

};

module.exports = Calculadora;