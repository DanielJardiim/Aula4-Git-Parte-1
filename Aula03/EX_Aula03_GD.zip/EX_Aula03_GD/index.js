const Calculadora = require('./calculadora');

var logbasev1 = Calculadora.logbasev1(11,3);
var soma = Calculadora.soma(16,5);
var subtracao = Calculadora.subtracao(1,6);
var multiplicacao = Calculadora.multiplicacao(18,9);
var divisao = Calculadora.divisao(8,1);

console.log("Logbasev1: ",logbasev1);
console.log("Soma: ",soma);
console.log("Subtracao: ",subtracao);
console.log("Multiplicacao: ",multiplicacao);
console.log("Divisao: ",divisao);