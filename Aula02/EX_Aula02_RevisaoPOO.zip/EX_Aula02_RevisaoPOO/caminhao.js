class Caminhao extends Veiculo{
    eixos;

    constructor(placa,ano,eixos){
        super(placa,ano);
        this.eixos = eixos;
    }

    setEixos(novoEixo){
        this.eixos = novoEixo;
    }

    getEixos(){
        this.eixos;
    }

    exibirDados(){
        console.log('Caminhão');
        super.exibirDados();
        console.log('Eixos:',this.eixos);
    }
}

var novoCaminhao = new Caminhao('HHH-777',2021,10);
novoCaminhao.exibirDados();
