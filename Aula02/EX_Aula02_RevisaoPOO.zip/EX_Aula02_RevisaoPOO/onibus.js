class Onibus extends Veiculo{
    assentos;

    constructor(placa,ano,assentos){
        super(placa,ano);
        this.assentos = assentos;
    }

    setAssentos(novoAssento){
        this.assentos = novoAssento;
    }

    getAssentos(){
        this.assentos;
    }

    exibirDados(){
        console.log('Ônibus');
        super.exibirDados();
        console.log('Assentos:',this.assentos)
    }
}

var novoOnibus = new Onibus('FFF-888',1998,25);
novoOnibus.exibirDados();